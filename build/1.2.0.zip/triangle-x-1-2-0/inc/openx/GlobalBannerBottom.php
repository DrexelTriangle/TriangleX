<!--/* OpenX Asynchronous JavaScript tag */-->


<div id="538317146_INSERT_SLOT_ID_HERE" style="width:728px;height:90px;margin:0;padding:0">
  <noscript><iframe id="9e6e8ebf9f" name="9e6e8ebf9f" src="//oncampusweb-d.openx.net/w/1.0/afr?auid=538317146&cb=INSERT_RANDOM_NUMBER_HERE" frameborder="0" scrolling="no" width="728" height="90"><a href="//oncampusweb-d.openx.net/w/1.0/rc?cs=9e6e8ebf9f&cb=INSERT_RANDOM_NUMBER_HERE" ><img src="//oncampusweb-d.openx.net/w/1.0/ai?auid=538317146&cs=9e6e8ebf9f&cb=INSERT_RANDOM_NUMBER_HERE" border="0" alt=""></a></iframe></noscript>
</div>
<script type="text/javascript">
  var OX_ads = OX_ads || [];
  OX_ads.push({
     slot_id: "538317146_INSERT_SLOT_ID_HERE",
     auid: "538317146"
  });
</script>

<script type="text/javascript" src="//oncampusweb-d.openx.net/w/1.0/jstag"></script>
